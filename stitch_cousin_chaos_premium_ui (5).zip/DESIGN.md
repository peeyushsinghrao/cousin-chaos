---
name: Cousin Chaos
colors:
  surface: '#17111f'
  surface-dim: '#17111f'
  surface-bright: '#3e3646'
  surface-container-lowest: '#110b1a'
  surface-container-low: '#1f1928'
  surface-container: '#231d2c'
  surface-container-high: '#2e2737'
  surface-container-highest: '#393242'
  on-surface: '#eadef3'
  on-surface-variant: '#cfc2d6'
  inverse-surface: '#eadef3'
  inverse-on-surface: '#352d3d'
  outline: '#988d9f'
  outline-variant: '#4d4354'
  surface-tint: '#ddb7ff'
  primary: '#ddb7ff'
  on-primary: '#490080'
  primary-container: '#b76dff'
  on-primary-container: '#400071'
  inverse-primary: '#842bd2'
  secondary: '#92dbff'
  on-secondary: '#003547'
  secondary-container: '#00c4fd'
  on-secondary-container: '#004d66'
  tertiary: '#ffb3b5'
  on-tertiary: '#680019'
  tertiary-container: '#ff5167'
  on-tertiary-container: '#5b0015'
  error: '#ffb4ab'
  on-error: '#690005'
  error-container: '#93000a'
  on-error-container: '#ffdad6'
  primary-fixed: '#f0dbff'
  primary-fixed-dim: '#ddb7ff'
  on-primary-fixed: '#2c0051'
  on-primary-fixed-variant: '#6900b3'
  secondary-fixed: '#bfe9ff'
  secondary-fixed-dim: '#6dd2ff'
  on-secondary-fixed: '#001f2a'
  on-secondary-fixed-variant: '#004d65'
  tertiary-fixed: '#ffdada'
  tertiary-fixed-dim: '#ffb3b5'
  on-tertiary-fixed: '#40000c'
  on-tertiary-fixed-variant: '#920027'
  background: '#17111f'
  on-background: '#eadef3'
  surface-variant: '#393242'
typography:
  display-xl:
    fontFamily: Anybody
    fontSize: 64px
    fontWeight: '800'
    lineHeight: '1.1'
    letterSpacing: -0.02em
  display-lg:
    fontFamily: Anybody
    fontSize: 48px
    fontWeight: '800'
    lineHeight: '1.1'
    letterSpacing: -0.02em
  headline-lg:
    fontFamily: Sora
    fontSize: 32px
    fontWeight: '700'
    lineHeight: '1.2'
  headline-lg-mobile:
    fontFamily: Sora
    fontSize: 28px
    fontWeight: '700'
    lineHeight: '1.2'
  body-lg:
    fontFamily: Plus Jakarta Sans
    fontSize: 18px
    fontWeight: '500'
    lineHeight: '1.6'
  body-md:
    fontFamily: Plus Jakarta Sans
    fontSize: 16px
    fontWeight: '400'
    lineHeight: '1.6'
  label-md:
    fontFamily: Sora
    fontSize: 14px
    fontWeight: '600'
    lineHeight: '1.4'
    letterSpacing: 0.05em
rounded:
  sm: 0.25rem
  DEFAULT: 0.5rem
  md: 0.75rem
  lg: 1rem
  xl: 1.5rem
  full: 9999px
spacing:
  container-margin: 24px
  gutter: 16px
  section-gap: 40px
  stack-sm: 8px
  stack-md: 16px
  stack-lg: 24px
---

## Brand & Style
The design system for this product is built on a "Dark Neon Glassmorphism" aesthetic, capturing the high-energy, unpredictable spirit of a premium party game. The brand personality is chaotic yet curated—designed to feel like a high-end nightclub or a futuristic arcade. It targets a Gen Z demographic (18-25) by avoiding "childish" brights in favor of deep, moody backgrounds punctuated by electric neon strikes.

The visual style utilizes **Glassmorphism** as its primary structural metaphor. Elements appear as frosted glass panes floating in a deep, atmospheric void. This creates a sense of depth and sophistication, ensuring the "Chaos" feels premium rather than cluttered. High-contrast typography and glowing accents guide the user through fast-paced gameplay loops.

## Colors
The palette is rooted in a deep, midnight-purple base (`#0A0512`), which provides the necessary contrast for the neon accents to "pop" as if they are light sources. 

- **Primary (Purple):** Used for main actions and brand flourishes.
- **Secondary (Cyan):** Used for interactive elements and success states.
- **Tertiary (Pink/Red):** Used for urgent prompts, "Chaos" events, and high-energy UI hits.
- **Accents (Green/Gold):** Reserved for rewards, leveling up, and special game modes.

The "Glass" effect is achieved using a very low-opacity white fill with a 15-20% opacity white border to simulate light catching the edge of a transparent surface.

## Typography
The typography strategy uses a hierarchy of three distinct fonts to manage energy and readability.

- **Display (Anybody):** A variable, high-impact font used for game titles, score announcements, and "Chaos" triggers. It should feel loud and expressive.
- **Headings (Sora):** A geometric sans-serif that brings a modern, tech-forward feel to the UI structure.
- **Body (Plus Jakarta Sans):** Selected for its friendly and open counters, ensuring game rules and card text remain legible even against complex glassmorphic backgrounds.

Apply `text-shadow: 0 0 12px {color}` to display text when using neon colors to simulate a glow effect.

## Layout & Spacing
This design system uses a **Fluid Grid** approach optimized for mobile-first interactions. The layout relies on generous vertical stacking to allow the background gradients and "floating particles" enough room to breathe.

- **Safe Areas:** A minimum 24px horizontal margin ensures content doesn't hit the screen edges.
- **Card-Based Architecture:** Elements are grouped into glass containers. Spacing between containers should be consistent (24px) to maintain a rhythmic vertical flow.
- **Visual Breathing Room:** Avoid dense clusters of information. Use `section-gap` to separate distinct game phases or menu categories.

## Elevation & Depth
Depth is the cornerstone of this design system. It is communicated through three layers:

1.  **The Void (Background):** The base `#0A0512` color, occasionally broken by large, soft radial gradients of Purple or Cyan at 10-20% opacity.
2.  **The Glass (Floating Layer):** Elements use `backdrop-filter: blur(20px)` and a thin `1px` border. This layer sits "above" the void. 
3.  **The Glow (Interaction Layer):** Active elements, like selected cards or primary buttons, emit an outer glow (`box-shadow`) matching their accent color.

**Shadows:** Use deep, large-radius shadows (`blur: 40px`, `spread: -10px`) with a slight tint of the primary color to make glass panels feel like they are hovering significantly above the background.

## Shapes
The shape language is dominated by large, organic radii that feel comfortable and "premium." 

- **Containers:** Use `rounded-lg` (16px) for standard cards.
- **Buttons:** All buttons must use `rounded-xl` (24px) or be fully pill-shaped to create a friendly, "squishy" tactile feel that encourages clicking.
- **Interactive States:** On hover or tap, shapes may subtly scale (1.02x) to reinforce the physical nature of the glass panels.

## Components

### Buttons
Primary buttons should be vibrant neon gradients (e.g., Purple to Cyan) with white text and a heavy glow. Secondary buttons use the glass style (blur + thin border). Use a minimum height of 56px for touch targets.

### Glass Cards
Cards are the primary content vessel. They must have a `backdrop-filter: blur(20px)` and a `background: rgba(255, 255, 255, 0.05)`. The border should be a top-down linear gradient from `rgba(255,255,255,0.2)` to `rgba(255,255,255,0.05)` to simulate overhead lighting.

### Input Fields
Inputs are dark glass containers with a subtle `1px` bottom border. Upon focus, the border should animate into a full neon glow of the primary color.

### Chips & Tags
Small, highly saturated capsules. Use the neon accent colors for categories (e.g., "Timed Mode" in Cyan, "Extreme" in Pink).

### Game Mode Icons
Icons should be multi-colored and "chunky," using the brand's neon palette. They should sit inside a glass circle with a subtle inner glow.

### Progress Bars
Track should be a dark glass "trough." The progress indicator should be a glowing neon gradient with a "spark" (a white-hot glow point) at the leading edge.